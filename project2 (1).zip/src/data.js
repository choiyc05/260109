export const list = [
  {title: "아이템1", content: "입니다", accept: 1 },
  {title: "아이템2", content: "입니다", accept: 2 },
]