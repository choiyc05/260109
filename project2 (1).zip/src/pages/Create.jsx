const Create = () => {
  return (
    <h1 className="text-center">생성 화면</h1>
  )
}
export default Create